//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by MFCApplication3.rc
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDR_MAINFRAME                   128
#define IDR_MFCApplication3TYPE         130
#define IDD_DIALOG1                     310
#define IDD_DIALOG_LABEL                310
#define IDD_DIALOG_BUTTON               311
#define IDD_DIALOG_EDITOR               312
#define IDD_DIALOG_ENTRY                313
#define IDC_BackColorBUTTON             1000
#define IDC_TextColorBUTTON             1001
#define IDC_FontBUTTON                  1003
#define IDC_EDIT2                       1004
#define IDC_EDIT3                       1005
#define IDC_EDIT1                       1006
#define IDC_RADIO_MICRO                 1007
#define IDC_RADIO_SMALL                 1008
#define IDC_RADIO_MEDIM                 1009
#define IDC_RADIO_LARGE                 1010
#define IDC_RADIO_DEFAULT               1011
#define IDC_RADIO1                      1012
#define IDC_RADIO2                      1013
#define IDC_RADIO3                      1014
#define IDC_BUTTON1                     1016
#define IDC_RADIO_YES                   1019
#define IDC_RADIO_NO                    1020
#define ID_ELEMENTOPTIONS_BUTTON        32771
#define ID_ELEMENTOPTIONS_TEXTBOX       32772
#define ID_BUTTON_SHOWTEXT              32773
#define ID_ELEMENTOPTIONS_BUTTON32774   32774
#define ID_ELEMENTOPTIONS_SHOWBUTTONTEXT 32775
#define ID_ELEMENTOPTIONS_BUTTON32776   32776
#define ID_ELEMENT_ADDBUTTONTEXT        32777
#define ID_ELEMENTOPTIONS_ADDLABEL      32778
#define A                               32779
#define ID_Menu                         32780
#define ID_ELEMENTOPTIONS_ADDBUTTON     32781
#define ID_ELEMENTOPTIONS_ADDBUTTON32782 32782
#define ID_ELEMENTOPTIONS_ADDBUTTON32783 32783
#define ID_ELEMENTOPTIONS_ADDCBUTTON    32784
#define ID_FILE_GENERATEXAML            32785
#define ID_EDIT_EDITFONT                32786
#define ID_REPAINT_REPAINT              32787
#define ID_ELEMENTOPTIONS_ADDEDITOR     32788
#define ID_ELEMENTOPTIONS_ADDENTRY      32789

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        320
#define _APS_NEXT_COMMAND_VALUE         32790
#define _APS_NEXT_CONTROL_VALUE         1021
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
