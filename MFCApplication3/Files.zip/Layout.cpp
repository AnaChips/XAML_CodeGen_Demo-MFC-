#include "stdafx.h"
#include "Layout.h"


Layout :: Layout()
{

}